<!DOCTYPE html>
<html lang="es">
    * Yesika Bernal

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/estilos.css">
    
   
    <title>GEMA SAS</title>
</head>

<body>
    <div class="grid-container" >
        <h1>Bienvenido </h1>
        
            <form action="pages/tablas.php" method="post" enctype="multipart/form-data">
            <input type="file" name="txt" id="txt">
            <input type="submit" value="Enviar Formulario" name="submit">
           
      
</div>

        
    </div>
</body>

</html>