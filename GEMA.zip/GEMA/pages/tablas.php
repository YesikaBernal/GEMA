<?php 
require_once('conecta.php'); 

?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/estilos.css">
    
   
    <title>GEMA SAS</title>
</head>
<?php

//Cadena
if (substr($_FILES['txt']['name'], -3)=="txt")
{
    //Guardar archivo en carpeta llamada descargas, añadiendo al nombre la fecha en que se guardo
  $fecha = date('y-m-d');
  $ruta = "descargas/";
  $txt = $fecha. "-". $_FILES['txt']['name'];
  move_uploaded_file($_FILES['txt']['tmp_name'], "$ruta$txt");

  $row = 1;
  $fp = fopen("$ruta$txt", "r");

  //Creación buble, revisión archivo por comas
   
  while($data = fgetcsv($fp, 1000, ","))
  {
      if($row!=1)
      {

        //insertar datos a BD 
          $num = count($data);
          $sql = $conn->prepare("INSERT INTO usuarios(email, nombre, apellido, id_estado)
          VALUES('$data[0]', '$data[1]', '$data[2]','$data[3]')");

         
         
         if($sql->execute()){
             echo "Datos guardado correctamente..";
             echo "<a href=\"consultar.php\">Consultar</a>";
             $sql1 = $conn->query("SELECT * FROM usuarios");
             
         }
         else{
             echo "No se realizo el envio";
             echo "<a href=\"..\index.php\">Inicio</a>";
            }
      }
      $row ++;
    }
    fclose($fp);

    echo "<div> Envio de datos</div>";
    exit;

}
else{
    echo"<p>Debe subir un archivo txt</p>";
    echo "<a href=\"..\index.php\">Inicio</a>";
}

?>
</html>
