/*
PDO: PHP DATA OBJECT
*/

<?php

//Se crea la BD método PDO
$servername ="localhost";
$username = "root";
$password ="";
try {
    $conn = new PDO("mysql:host=$servername", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $SQL = "CREATE DATABASE IF NOT EXISTS Gema ;
           USE Gema;

           CREATE TABLE IF NOT EXISTS estado(
                id_estado INT(2) NOT NULL PRIMARY KEY,
                nom_estado VARCHAR(10) NOT NULL
            );

            INSERT INTO estado(id_estado, nom_estado)
            VALUES('1', 'Activo');
            INSERT INTO estado(id_estado, nom_estado)
            VALUES('2', 'Inactivo');
            INSERT INTO estado(id_estado, nom_estado)
            VALUES('3', 'En espera');

            
           CREATE TABLE IF NOT EXISTS usuarios(
               id_usuario INT(20) NOT NULL AUTO_INCREMENT,
               email VARCHAR(50) NOT NULL,
               nombre VARCHAR(30),
               apellido VARCHAR(30),
               id_estado INT(2) NOT NULL,
               INDEX (id_estado),
               FOREIGN KEY (id_estado) REFERENCES estado(id_estado),
               PRIMARY KEY (id_usuario)
            );
            
            
            
            
            

            
            



    ";
    $conn->exec($SQL);

} catch (PDOException $error) {
    //throw $th;
    echo $SQL."<br>".$error->getMassage();
}
?>