<?php
require_once("conecta.php");
$SQL = $conn->query("SELECT * FROM estado");
$SQL1 = $conn->query("SELECT * FROM usuarios");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/estilos.css">
    
   
    <title>GEMA SAS</title>
</head>
<body>
    
    <form action="consultar.php" method="POST"> 
    <select name="estado">
        <?php 
            foreach($SQL as $estado){
                echo "<option value=".$estado['id_estado'].">".$estado['nom_estado']."</option>";
                echo "<a href=\"..\index.php\">Inicio</a>";
            }
        ?> 
    </select>
    <input type="submit" value="Consultar">
    </form>
    <br>
    <section class="contenedor">
            <table>
                <tr>
                    <th>Email</th>
                    <th> Nombre</th>
                    <th>Apellido</th>
                </tr>
                
                
    <?php
    //Realizacion Inner Join para obtener los datos de las 2 tablas
    echo "<a href=\"..\index.php\">Inicio</a>";
        $estado=(!empty ($_POST["estado"])) ? $_POST["estado"] : NULL; 
        $SQL2= $conn->query("SELECT E.id_estado, E.nom_estado, U.email, U.nombre, U.apellido
                From estado  E 
                INNER JOIN usuarios  U  
                ON E.id_estado = U.id_estado"); 
                
                while ($fila=$SQL2->fetch(PDO::FETCH_ASSOC)){
                    echo'
                    <tr>
                    <td>'.$fila['email'].'</td>
                    <td>'.$fila['nombre'].'</td>
                    <td>'.$fila['apellido'].'</td>
                    </tr>';
                }
      
    ?>
    </table>
    </section>
</body>
</html>
    

        
